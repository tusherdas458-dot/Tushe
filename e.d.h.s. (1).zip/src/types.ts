export type ServiceType = 
    | "Aadhaar" 
    | "PAN" 
    | "Passport" 
    | "Online Forms"
    | "Travel Booking"
    | "Printing"
    | "Xerox"
    | "Scanning"
    | "Lamination"
    | "Other";

export interface ApplicationFormData {
    service: ServiceType;
    name: string;
    phone: string;
    email: string;
    details: string;
    documentBase64?: string;
    documentName?: string;
    documentType?: string;
}
