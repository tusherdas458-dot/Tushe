import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, Loader2, AlertCircle, UploadCloud, File as FileIcon } from 'lucide-react';
import { ServiceType, ApplicationFormData } from '../types';

interface ApplicationFormProps {
    initialService: ServiceType | null;
    onClose: () => void;
}

export const ApplicationForm: React.FC<ApplicationFormProps> = ({ initialService, onClose }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [formData, setFormData] = useState<ApplicationFormData>({
        service: initialService || "Other",
        name: "",
        phone: "",
        email: "",
        details: ""
    });
    
    type Status = 'idle' | 'submitting' | 'success' | 'error';
    const [status, setStatus] = useState<Status>('idle');
    const [errorMessage, setErrorMessage] = useState("");

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                 setErrorMessage("File is too large. Maximum size is 5MB.");
                 return;
            }
            setErrorMessage("");
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({
                    ...prev,
                    documentBase64: reader.result as string,
                    documentName: file.name,
                    documentType: file.type
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('submitting');
        setErrorMessage("");

        try {
            const apiHost = (import.meta as any).env.VITE_API_URL || "";
            const response = await fetch(`${apiHost}/api/apply`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                setStatus('success');
            } else {
                throw new Error("Failed to submit application");
            }
        } catch (err: any) {
            console.error(err);
            setStatus('error');
            setErrorMessage(err.message || "An unexpected error occurred. Please try again.");
        }
    };

    return (
        <AnimatePresence>
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm sm:p-6"
            >
                <div className="absolute inset-0 transition-opacity" aria-hidden="true" onClick={onClose} />
                
                <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 20 }}
                    className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 text-left overflow-y-auto max-h-[90vh]"
                    role="dialog" aria-modal="true" aria-labelledby="modal-headline"
                >
                    <div className="absolute top-0 right-0 pt-4 pr-4">
                        <button
                            type="button"
                            className="text-gray-400 transition-colors bg-white rounded-md hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            onClick={onClose}
                        >
                            <span className="sr-only">Close</span>
                            <X className="w-6 h-6" />
                        </button>
                    </div>

                    {status === 'success' ? (
                        <div className="py-8 text-center">
                            <motion.div 
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="flex items-center justify-center w-16 h-16 mx-auto mb-6 text-green-600 bg-green-100 rounded-full"
                            >
                                <CheckCircle2 className="w-8 h-8" />
                            </motion.div>
                            <h3 className="mb-2 text-2xl font-semibold text-gray-900">Application Received</h3>
                            <p className="mb-6 text-gray-500">
                                Thank you for applying! The owner has been notified and will contact you shortly regarding your {formData.service} request.
                            </p>
                            <button
                                onClick={onClose}
                                className="inline-flex justify-center w-full px-4 py-2 text-base font-medium text-white transition-colors bg-blue-600 border border-transparent rounded-lg shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 disabled:opacity-50 sm:text-sm"
                            >
                                Close
                            </button>
                        </div>
                    ) : (
                        <div>
                            <div className="mb-6">
                                <h3 className="text-xl font-semibold leading-6 text-gray-900" id="modal-headline">
                                    Apply for a Service
                                </h3>
                                <p className="mt-1 text-sm text-gray-500">
                                    Fill out the details below and we will get back to you immediately.
                                </p>
                            </div>
                            
                            {status === 'error' && (
                                <div className="p-4 mb-6 rounded-md bg-red-50 flex gap-3 text-red-800 text-sm">
                                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                                    <span>{errorMessage}</span>
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <label htmlFor="service" className="block text-sm font-medium text-gray-700">Service Type</label>
                                    <select
                                        id="service"
                                        name="service"
                                        value={formData.service}
                                        onChange={handleChange}
                                        className="block w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white"
                                    >
                                        <option value="Aadhaar">Aadhaar</option>
                                        <option value="PAN">PAN</option>
                                        <option value="Passport">Passport</option>
                                        <option value="Online Forms">Online Forms</option>
                                        <option value="Travel Booking">Travel Booking</option>
                                        <option value="Printing">Printing</option>
                                        <option value="Xerox">Xerox</option>
                                        <option value="Scanning">Scanning</option>
                                        <option value="Lamination">Lamination</option>
                                        <option value="Other">Other Service</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                                    <input
                                        type="text"
                                        name="name"
                                        id="name"
                                        required
                                        value={formData.name}
                                        onChange={handleChange}
                                        className="block w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                                        placeholder="John Doe"
                                    />
                                </div>

                                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <div>
                                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                                        <input
                                            type="tel"
                                            name="phone"
                                            id="phone"
                                            required
                                            value={formData.phone}
                                            onChange={handleChange}
                                            className="block w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                                            placeholder="+1 234 567 8900"
                                        />
                                    </div>
                                    <div>
                                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address <span className="text-gray-400 font-normal">(Optional)</span></label>
                                        <input
                                            type="email"
                                            name="email"
                                            id="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            className="block w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                                            placeholder="john@example.com"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label htmlFor="details" className="block text-sm font-medium text-gray-700">Additional Details</label>
                                    <textarea
                                        name="details"
                                        id="details"
                                        rows={3}
                                        value={formData.details}
                                        onChange={handleChange}
                                        className="block w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400 resize-none"
                                        placeholder="Any specific instructions or urgency? (Optional)"
                                    ></textarea>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Supporting Document <span className="text-gray-400 font-normal">(Optional)</span></label>
                                    <div 
                                        className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:border-blue-500 transition-colors bg-gray-50"
                                        onClick={() => fileInputRef.current?.click()}
                                    >
                                        <div className="space-y-1 text-center flex flex-col items-center">
                                            {formData.documentName ? (
                                                <>
                                                    <FileIcon className="mx-auto h-10 w-10 text-blue-500 mb-2" />
                                                    <span className="text-sm font-semibold text-blue-600 truncate max-w-xs">{formData.documentName}</span>
                                                    <span className="text-xs text-gray-500">Click to change file</span>
                                                </>
                                            ) : (
                                                <>
                                                    <UploadCloud className="mx-auto h-10 w-10 text-gray-400 mb-2" />
                                                    <div className="flex text-sm text-gray-600">
                                                        <span className="relative cursor-pointer bg-transparent rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                                                            <span>Upload a file</span>
                                                            <input 
                                                                id="file-upload" 
                                                                name="file-upload" 
                                                                type="file" 
                                                                className="sr-only"
                                                                ref={fileInputRef}
                                                                onChange={handleFileChange}
                                                                accept=".pdf,.jpg,.jpeg,.png"
                                                            />
                                                        </span>
                                                        <p className="pl-1">or drag and drop</p>
                                                    </div>
                                                    <p className="text-xs text-gray-500">
                                                        PNG, JPG, PDF up to 5MB
                                                    </p>
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </div>

                                <div className="pt-4 mt-5 sm:flex sm:flex-row-reverse border-t border-gray-100">
                                    <button
                                        type="submit"
                                        disabled={status === 'submitting'}
                                        className="inline-flex justify-center w-full px-4 py-2 text-base font-medium text-white transition-colors bg-blue-600 border border-transparent rounded-lg shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed items-center min-w-[120px]"
                                    >
                                        {status === 'submitting' ? (
                                            <>
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                Submitting...
                                            </>
                                        ) : (
                                            "Submit Application"
                                        )}
                                    </button>
                                    <button
                                        type="button"
                                        onClick={onClose}
                                        disabled={status === 'submitting'}
                                        className="inline-flex justify-center w-full px-4 py-2 mt-3 text-base font-medium text-gray-700 transition-colors bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:w-auto sm:text-sm disabled:opacity-50"
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
};
