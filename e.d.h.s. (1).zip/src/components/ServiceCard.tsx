import React from 'react';
import { motion } from 'motion/react';
import { ServiceType } from '../types';

interface ServiceCardProps {
    title: ServiceType;
    onSelect: (service: ServiceType) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ title, onSelect }) => {
    return (
        <motion.button
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(title)}
            className="flex items-center justify-between p-6 bg-white rounded-2xl shadow-[0_2px_10px_rgba(0,0,0,0.05)] border border-transparent hover:border-blue-100 transition-all w-full focus:outline-none"
        >
            <span className="text-lg font-bold text-[#1e3a8a]">{title}</span>
            <span className="px-5 py-2 text-sm font-semibold text-[#1e3a8a] bg-[#e0f2fe] rounded-full">
                Request
            </span>
        </motion.button>
    );
};
