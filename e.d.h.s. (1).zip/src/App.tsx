import { useState } from 'react';
import { ServiceCard } from './components/ServiceCard';
import { ApplicationForm } from './components/ApplicationForm';
import { ServiceType } from './types';

export default function App() {
  const [selectedService, setSelectedService] = useState<ServiceType | null>(null);

  const handleSelectService = (service: ServiceType) => {
    setSelectedService(service);
  };

  const closeForm = () => {
    setSelectedService(null);
  };

  const services: ServiceType[] = [
    "Aadhaar",
    "PAN",
    "Passport",
    "Online Forms",
    "Travel Booking",
    "Printing",
    "Xerox",
    "Scanning",
    "Lamination"
  ];

  return (
    <div className="min-h-screen bg-[#eff6ff] text-gray-900 font-sans flex flex-col">
      {/* Header */}
      <header className="w-full bg-gradient-to-r from-[#2563eb] via-[#60a5fa] to-[#eab308] pt-16 pb-12 px-4 shadow-md">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white mb-4 drop-shadow-sm">
            Easy Doc Hubs Shop
          </h1>
          <p className="text-lg sm:text-xl font-medium text-white/95 drop-shadow-sm">
            All Your Printing & Digital Services under One Roof
          </p>
        </div>
      </header>

      {/* Services Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
        <div className="mb-10 text-center">
            <h2 className="text-3xl font-extrabold tracking-tight text-[#1e3ba8] mb-2">Our Services</h2>
        </div>
        
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
             <ServiceCard
               key={service}
               title={service}
               onSelect={handleSelectService}
             />
          ))}
        </div>
      </section>

      {/* Payment Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8 text-center flex flex-col items-center">
            <h2 className="text-3xl font-extrabold tracking-tight text-[#1e3ba8] mb-2">Scan & Pay</h2>
            <p className="mt-2 text-gray-600 max-w-lg">Pay securely using any UPI app (GPay, PhonePe, Paytm). Take a screenshot after successful payment to attach with your application.</p>
        </div>
        
        <div className="flex flex-col items-center justify-center p-8 bg-white rounded-3xl shadow-[0_4px_20px_rgba(0,0,0,0.06)] border border-transparent mx-auto hover:shadow-[0_8px_30px_rgba(0,0,0,0.1)] transition-shadow w-full max-w-sm">
             <div className="p-3 bg-white rounded-2xl mb-4 border border-gray-100 shadow-sm relative overflow-hidden flex items-center justify-center w-56 h-56">
               <img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi%3A%2F%2Fpay%3Fpa%3Dpritamdas55667%40okicici%26pn%3DEasy%20Doc%20Hubs%20Shop" alt="Payment QR Code" className="w-full h-full object-cover mix-blend-multiply opacity-90" />
               <div className="absolute inset-0 flex items-center justify-center">
                 <div className="bg-white p-2.5 rounded-full shadow-lg border border-gray-50 flex items-center justify-center">
                   <svg width="28" height="28" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22.096 38.318c-1.393 0-2.618-.46-3.676-1.38-1.036-.92-1.554-2.072-1.554-3.456v-2.318h-4.339V27.35l4.339-.02v-3.795c0-2.093.597-3.832 1.79-5.218 1.194-1.386 2.766-2.08 4.717-2.08 1.433 0 2.716.273 3.848.818l-1.074 3.018c-.858-.46-1.743-.69-2.656-.69-1.035 0-1.854.34-2.457 1.018-.604.678-.905 1.637-.905 2.875v3.982h4.512v3.812h-4.512v2.3c0 .531.157.94.471 1.228.314.288.756.432 1.326.432.485 0 .97-.085 1.455-.256l.999 3.024A9.296 9.296 0 0 1 22.096 38.318Zm17.77-11.834v11.53c0 2.05-.623 3.633-1.87 4.748-1.246 1.116-2.85 1.674-4.811 1.674-1.761 0-3.32-.422-4.677-1.266l1.245-3.082a6.837 6.837 0 0 0 3.655.992c1.035 0 1.834-.236 2.396-.708.562-.472.843-1.168.843-2.086v-1.12c-.523.59-1.159 1.055-1.91 1.396-.75.34-1.57.51-2.46.51-1.636 0-3.023-.625-4.161-1.874-1.138-1.25-1.706-2.825-1.706-4.726 0-1.848.565-3.41 1.696-4.686 1.13-1.275 2.508-1.912 4.133-1.912.874 0 1.68.163 2.417.49.736.326 1.378.796 1.926 1.41V26.484h3.275Zm-5.753.856c-1.168 0-2.122.45-2.862 1.349-.74.9-1.11 2.046-1.11 3.44 0 1.371.36 2.502 1.08 3.393.72.89 1.656 1.336 2.808 1.336 1.152 0 2.102-.451 2.852-1.355.748-.903 1.123-2.043 1.123-3.418 0-1.36-.375-2.492-1.123-3.393-.75-.9-1.706-1.352-2.868-1.352Z" fill="#5F6368"/>
                      <path d="M11.603 36.634v-27.1H18.73c2.093 0 3.864.673 5.312 2.02S26.216 14.887 26.216 17c0 2.112-.725 3.906-2.174 5.38S20.823 24.6 18.73 24.6h-3.435v12.034h-3.692Zm3.692-15.426h3.435c1.138 0 2.106-.39 2.905-1.171.798-.78 1.196-1.782 1.196-3.003 0-1.178-.396-2.16-1.189-2.946-.793-.785-1.751-1.178-2.875-1.178h-3.472v8.298Z" fill="#5F6368"/>
                   </svg>
                 </div>
               </div>
             </div>
             <div className="text-center w-full mt-2">
                 <p className="text-xl font-bold text-gray-800 tracking-wide">Easy Doc Hubs Shop</p>
                 <div className="inline-flex items-center justify-center space-x-2 bg-blue-50 text-[#1e3ba8] px-4 py-2 hover:bg-blue-100 transition-colors rounded-full text-sm font-semibold mt-3 cursor-pointer">
                    <span>UPI ID: pritamdas55667@okicici</span>
                 </div>
                 <p className="text-xs text-gray-500 mt-5 px-1 tracking-wide leading-relaxed">
                   Upload your payment receipt screenshot within the application form under "Supporting Document" to process your request faster.
                 </p>
             </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 text-center">
        <div className="text-sm text-gray-500 font-medium">
          &copy; {new Date().getFullYear()} Easy Doc Hubs Shop. All rights reserved.
        </div>
      </footer>

      {/* Application Modal */}
      {selectedService && (
        <ApplicationForm 
          initialService={selectedService} 
          onClose={closeForm} 
        />
      )}
    </div>
  );
}
