import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import twilio from "twilio";
import nodemailer from "nodemailer";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "20mb" }));

  // API endpoint for handling applications
  app.post("/api/apply", async (req, res) => {
    const { service, name, phone, email, details } = req.body;

    const ownerEmail = process.env.OWNER_EMAIL;
    const targetEmails = ownerEmail ? `${ownerEmail}, tusherdas458@gmail.com` : "tusherdas458@gmail.com";
    const ownerPhone = process.env.OWNER_PHONE;
    
    let smsSent = false;
    let emailSent = false;
    const errors: string[] = [];

    // Attempt to send Twilio SMS
    if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER && ownerPhone) {
      try {
        let phoneToSend = ownerPhone.trim();
        if (/^\d{10}$/.test(phoneToSend)) {
            phoneToSend = '+91' + phoneToSend;
        } else if (!phoneToSend.startsWith('+')) {
            phoneToSend = '+' + phoneToSend;
        }

        const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        await client.messages.create({
          body: `New E.D.H.S Application!\nService: ${service}\nName: ${name}\nPhone: ${phone}\nDetails: ${details}`,
          from: process.env.TWILIO_PHONE_NUMBER,
          to: phoneToSend,
        });
        smsSent = true;
      } catch (e: any) {
        console.error("Twilio error:", e);
        errors.push(`Failed to send SMS: ${e.message}`);
      }
    } else {
        console.log("Skipping SMS Notification: Twilio credentials or OWNER_PHONE undefined in environment.");
    }

    // Attempt to send Notification via Email
    if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
      try {
        const port = parseInt(process.env.SMTP_PORT || "587");
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: port,
          secure: port === 465 || process.env.SMTP_SECURE === "true",
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
          tls: {
            rejectUnauthorized: false
          }
        });

        const mailOptions: any = {
          from: process.env.SMTP_USER,
          to: targetEmails,
          subject: `New E.D.H.S Application: ${service}`,
          text: `A new application has been received.\n\nService Requested: ${service}\nApplicant Name: ${name}\nApplicant Phone: ${phone}\nApplicant Email: ${email || 'N/A'}\nDetails: ${details}`,
        };

        if (req.body.documentBase64) {
          try {
            // Strip the data:image/png;base64, prefix if present
            const content = req.body.documentBase64.includes(',') 
                ? req.body.documentBase64.split(',')[1] 
                : req.body.documentBase64;
                
            mailOptions.attachments = [
              {
                filename: req.body.documentName || 'document',
                content: content,
                encoding: 'base64'
              }
            ];
          } catch(e) {
            console.error("Error creating attachment", e);
          }
        }

        await transporter.sendMail(mailOptions);
        emailSent = true;
      } catch (e: any) {
        console.error("Email error:", e);
        errors.push(`Failed to send Email: ${e.message}`);
      }
    } else {
        console.log("Skipping Email Notification: SMTP credentials undefined in environment.");
    }

    res.json({ 
        success: true, 
        message: "Application received. Owner has been notified (if configured).", 
        smsSent, 
        emailSent, 
        errors 
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
